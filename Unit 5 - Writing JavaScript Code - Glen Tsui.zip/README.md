# Recipes on Hand
 Recipes on Hand presents the user with healthy and high-quality recipes on demand using the ingredients they have on hand. This tool will save many trips to the grocery store, finally using the food that may spoil soon, and open a pathway to infinite culinary possibilities.
